﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DemoForExcelWorkBook
{
    public partial class ExcelWorrkBookOverlay : Form
    {
        public ExcelWorrkBookOverlay()
        {
            InitializeComponent();
        }

        public void OpenExcel(string workBookFileName)
        {
            string[] fileNameArray = workBookFileName.Split('\\');

            int tabIndex = this.excelTabContainer.TabPages.Count;

            this.excelTabContainer.TabPages.Add(new TabPage());

            ExcelWrapper excelWrapper = new ExcelWrapper();

            excelWrapper.Dock = DockStyle.Fill;

            this.excelTabContainer.TabPages[tabIndex].Controls.Add(excelWrapper);
            this.excelTabContainer.TabPages[tabIndex].Text = fileNameArray[fileNameArray.Length - 1];

            this.excelTabContainer.SelectedIndexChanged -= new System.EventHandler(excelTabContainer_SelectedIndexChanged);
            this.excelTabContainer.SelectedIndex = tabIndex;
            this.excelTabContainer.SelectedIndexChanged += new System.EventHandler(excelTabContainer_SelectedIndexChanged);

            excelWrapper.OpenFile(workBookFileName);
        }

        private void excelTabContainer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.excelTabContainer.SelectedTab == null ||
                this.excelTabContainer.SelectedTab.Controls == null ||
                this.excelTabContainer.SelectedTab.Controls.Count.Equals(0))
            {
                return;
            }

            foreach (TabPage tabPage in this.excelTabContainer.TabPages)
            {
                if (tabPage.Controls == null ||
                    tabPage.Controls.Count.Equals(0))
                    continue;

                ExcelWrapper excelWrapperInTab = tabPage.Controls[0] as ExcelWrapper;

                excelWrapperInTab.Visible = false;
            }

            ExcelWrapper excelWrapper = this.excelTabContainer.SelectedTab.Controls[0] as ExcelWrapper;

            if (excelWrapper != null)
            {
                excelWrapper.Visible = true;

                excelWrapper.Activate();
            }
        }

        private void excelTabContainer_ControlRemoved(object sender, ControlEventArgs e)
        {
            ExcelWrapper excelWrapper = null;

            foreach (object control in this.excelTabContainer.SelectedTab.Controls)
            {
                if (control is ExcelWrapper)
                {
                    excelWrapper = control as ExcelWrapper;

                    excelWrapper.ReleaseExcelFile(false);
                }
            }

            if (this.excelTabContainer.TabPages.Count.Equals(1))
            {
                this.FormClosing -= ExcelWorrkBookOverlay_FormClosing;
                this.Close();
                this.FormClosing += ExcelWorrkBookOverlay_FormClosing;
   
                if (excelWrapper != null)
                    excelWrapper.ReleaseExcelFile(true);
            }
        }

        private void ExcelWorrkBookOverlay_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void ExcelWorrkBookOverlay_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.excelTabContainer.ControlRemoved -= this.excelTabContainer_ControlRemoved;
            for (int i = 0; i < this.excelTabContainer.TabPages.Count; i++)
            {
                if (this.excelTabContainer.TabPages[i].Controls.Count > 0)
                {
                    ExcelWrapper excelWrapper = this.excelTabContainer.TabPages[i].Controls[0] as ExcelWrapper;

                    if (!excelWrapper.Saved)
                    {
                        DialogResult dialog = MessageBox.Show("Do you want to save the changes you made to" + this.excelTabContainer.TabPages[i].Text + "?",
                                                "Express Excel", MessageBoxButtons.YesNoCancel);

                        if (dialog == DialogResult.Yes)
                        {
                            excelWrapper.SaveExcelFile();
                        }
                        else if (dialog == DialogResult.Cancel)
                        {
                            e.Cancel = true;
                            continue;

                        }
                    }

                    this.excelTabContainer.TabPages.RemoveAt(i);

                    excelWrapper.ReleaseExcelFile(true);
                }
            }

            this.excelTabContainer.ControlRemoved += this.excelTabContainer_ControlRemoved;
        }
    }
}
