﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Threading;
using System.Windows.Forms;
using AxSHDocVw;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Interop.Excel;


namespace DemoForExcelWorkBook
{
    public partial class ExcelWrapper : UserControl
    {
        [DllImport("ole32.dll")]
        static extern int GetRunningObjectTable(uint reserved, out IRunningObjectTable pprot);
        [DllImport("ole32.dll")]
        static extern int CreateBindCtx(uint reserved, out IBindCtx pctx);

        #region Fields

        /// <summary>Contains a reference to the hosting application.</summary>
        private Microsoft.Office.Interop.Excel.Application m_XlApplication = null;
        /// <summary>Contains a reference to the active workbook.</summary>
        private Microsoft.Office.Interop.Excel.Workbook m_Workbook = null;

        /// <summary>Contains the path to the workbook file.</summary>
        public string m_ExcelFileName = string.Empty;

        public string m_ExcelTitleName = string.Empty;

        private delegate void Action();

        private System.Globalization.CultureInfo currentCI;

        #endregion Fields

        #region Construction
        public ExcelWrapper()
        {
            InitializeComponent();
        }
        #endregion Construction

        #region Properties
        [Browsable(false)]
        public _Workbook Workbook
        {
            get { return m_Workbook; }
        }

        public bool Saved
        {
            get 
            {

                this.Visible = true;

                System.Threading.Thread.CurrentThread.CurrentCulture = currentCI;
                
                try
                {
                    return m_Workbook != null && m_Workbook.Saved;
                }
                catch
                {
                    return true;
                }
            }
        }

        public new bool Visible 
        {
            get 
            {
                return base.Visible;
            }
            set
            {
                base.Visible = value;

                this.excelWebBrowser.Visible = value;
            }
        }

        #endregion Properties

        #region Methods

        public void OpenFile(string fileName)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

            currentCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            
            // Check the file exists
            if (!System.IO.File.Exists(fileName)) throw new Exception();

            m_ExcelFileName = fileName;

            FileInfo excelFileInfo = new FileInfo(this.m_ExcelFileName);

            m_ExcelTitleName = excelFileInfo.Name;

            Object refmissing = System.Reflection.Missing.Value;

            this.excelWebBrowser.Navigate(m_ExcelFileName, ref refmissing, ref refmissing, ref refmissing, ref refmissing);   
        }

        public void Activate() 
        {
            try
            {   
                Object refmissing = System.Reflection.Missing.Value;

                this.excelWebBrowser.ExecWB(SHDocVw.OLECMDID.OLECMDID_HIDETOOLBARS, SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER, ref refmissing, ref refmissing);
                
                m_Workbook.Activate();
            }
            catch (Exception e)
            {
                //Utility.Log.InfoLogEvent.LogException(e);
            }
        }

        private void OpenExcelFileInThread(string fileName)
        {
            Thread tread = new Thread(new ParameterizedThreadStart(BeginOpenExcelFile));
            tread.SetApartmentState(ApartmentState.STA);
            tread.Start(fileName);
        }

        private void BeginOpenExcelFile(object fileName) 
        {
            this.Invoke(new Action(delegate()
            {
                this.excelWebBrowser = new AxWebBrowser();
                this.excelWebBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
                this.excelWebBrowser.Enabled = true;
                this.excelWebBrowser.Location = new System.Drawing.Point(0, 0);
                this.excelWebBrowser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWebBrowser1.OcxState")));
                this.excelWebBrowser.Size = new System.Drawing.Size(420, 400);
                this.excelWebBrowser.TabIndex = 0;
                this.excelWebBrowser.DocumentComplete += new AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEventHandler(excelWebBrowser_DocumentComplete);
                this.Controls.Add(this.excelWebBrowser);

                Object refmissing = System.Reflection.Missing.Value;
                this.excelWebBrowser.Navigate(fileName.ToString(), ref refmissing, ref refmissing, ref refmissing, ref refmissing);
            
            }));
        }

        public void SaveExcelFile() 
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = currentCI;
            try
            {
                if (m_Workbook != null)
                    m_Workbook.Save();
            }
            catch (Exception e)
            {
                //Utility.Log.InfoLogEvent.LogException(e);
            }
        }

        public void ReleaseExcelFile(bool allClosed)
        {
            if (m_Workbook == null)
            {
                this.excelWebBrowser.Dispose();
                return;
            }
            try
            {
                m_Workbook.Close(false);

                System.Runtime.InteropServices.Marshal.ReleaseComObject(m_Workbook);

                m_Workbook = null;

                if (allClosed)
                {
                    m_XlApplication.Quit();

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(m_XlApplication);

                    m_XlApplication = null;
                }

                if (!this.excelWebBrowser.IsDisposed)
                {
                    this.excelWebBrowser.Dispose();
                }

                GC.Collect();
            }
            catch (Exception e)
            {
                //Utility.Log.InfoLogEvent.LogException(e);
            }
        }


        private void Worksheet_SheetSelectionChange(object sender, Range range)
        {
            //OnExcelCellClick(sender, range);
        }

        private void excelWebBrowser_DocumentComplete(object sender, DWebBrowserEvents2_DocumentCompleteEvent e) 
        {
            //Object refmissing = System.Reflection.Missing.Value;

            //this.excelWebBrowser.ExecWB(SHDocVw.OLECMDID.OLECMDID_HIDETOOLBARS, SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER); 

            m_Workbook = this.excelWebBrowser.Document as Workbook;

            if (m_Workbook != null)
            {
                m_XlApplication = m_Workbook.Application;
                
                try
                {
                    m_Workbook.Activate();
                }
                catch (Exception ex)
                {
                    //Utility.Log.InfoLogEvent.LogException(ex);
                }

                m_Workbook.SheetSelectionChange += new WorkbookEvents_SheetSelectionChangeEventHandler(Worksheet_SheetSelectionChange);
            }
        }

        #endregion Methods

        private void excelWebBrowser_NavigateComplete2(object sender, DWebBrowserEvents2_NavigateComplete2Event e)
        {
            this.excelWebBrowser.ExecWB(SHDocVw.OLECMDID.OLECMDID_HIDETOOLBARS, SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER);  //显示工具栏

            Object o = e.pDisp;
            Object oDocument = o.GetType().InvokeMember("Document", BindingFlags.GetProperty, null, o, null);
            Object oApplication = o.GetType().InvokeMember("Application", BindingFlags.GetProperty, null, oDocument, null);
            Object oName = o.GetType().InvokeMember("Name", BindingFlags.GetProperty, null, oApplication, null);
            this.m_XlApplication= (Microsoft.Office.Interop.Excel.Application)oApplication;
        }    
    }
}

