﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DemoForExcelWorkBook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.Filter = "(*.xls; *.xlsx; *.xlsm; *.xlsb)|*.XLS; *.XLSX; *.XLSM; *.XLSB";
            if (this.openFileDialog1.ShowDialog() == DialogResult.Cancel) return;

            ExcelWorrkBookOverlay workbookOpenOverlay = (ExcelWorrkBookOverlay)Application.OpenForms["ExcelWorrkBookOverlay"];
            if (workbookOpenOverlay == null)
            {
                workbookOpenOverlay = new ExcelWorrkBookOverlay();
            }

            workbookOpenOverlay.OpenExcel(openFileDialog1.FileName);

            if (!workbookOpenOverlay.Visible)
            {
                workbookOpenOverlay.Show();
            }
            return;
        }
    }
}
