﻿
namespace DemoForExcelWorkBook
{
    partial class ExcelWrapper
    {
        /// <summary>Required designer variable.</summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>Clean up any resources being used.</summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            ReleaseExcelFile(false);

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExcelWrapper));
            this.OpenExcelFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.excelWebBrowser = new AxSHDocVw.AxWebBrowser();
            ((System.ComponentModel.ISupportInitialize)(this.excelWebBrowser)).BeginInit();
            this.SuspendLayout();
            // 
            // OpenExcelFileDialog
            // 
            this.OpenExcelFileDialog.FileName = "\"* Excel files | *.xls\"";
            // 
            // excelWebBrowser
            // 
            this.excelWebBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.excelWebBrowser.Enabled = true;
            this.excelWebBrowser.Location = new System.Drawing.Point(0, 0);
            this.excelWebBrowser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("excelWebBrowser.OcxState")));
            this.excelWebBrowser.Size = new System.Drawing.Size(420, 400);
            this.excelWebBrowser.TabIndex = 0;
            this.excelWebBrowser.NavigateComplete2 += new AxSHDocVw.DWebBrowserEvents2_NavigateComplete2EventHandler(this.excelWebBrowser_NavigateComplete2);
            this.excelWebBrowser.DocumentComplete += new AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEventHandler(this.excelWebBrowser_DocumentComplete);
            // 
            // ExcelWrapper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.excelWebBrowser);
            this.Name = "ExcelWrapper";
            this.Size = new System.Drawing.Size(420, 400);
            ((System.ComponentModel.ISupportInitialize)(this.excelWebBrowser)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.ComponentResourceManager resources;
        private System.Windows.Forms.OpenFileDialog OpenExcelFileDialog;
        private AxSHDocVw.AxWebBrowser excelWebBrowser;
    }
}
